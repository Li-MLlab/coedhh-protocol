# CoDe-HH Release — Budget-Matching Protocol for LLM-Based Algorithm Design

Reproduction artifact for

> **Comparing LLM-Based Algorithm-Design Systems Fairly: A
> Three-Denominator Budget-Matching Protocol, an Idempotent
> Failure-Handling Rule, and a Reporting Checklist for Automated Algorithm
> Design**
>
> Jie Li, School of Business Administration and Tourism Management,
> Yunnan University, Kunming, China
> *Journal of Heuristics* (Springer) — under review

```bash
git clone https://github.com/somework666/coedhh-protocol.git
cd coedhh-protocol
pip install -r requirements.txt
python code/reproduce.py --verify    # checks the statistics the paper quotes
```

This repository contains the code and data needed to regenerate every
quantitative claim in the manuscript. Nothing here depends on network
access, on a language-model API, or on any file that is not in this
repository.

---

## What is in here

```
code/        the scripts; five of them regenerate the manuscript's tables
data/        per-event cost ledgers and test-set results (JSON)
manuscript/  the submitted manuscript source (LaTeX)
```

`data/` is organised by what the data is, not by what produced it:

| Path | What it holds | Runs |
|---|---|---|
| `data/ledgers/stageB/` | per-event cost ledgers, LLM arms | 400 |
| `data/test/stageB_test/` | test-set results, LLM arms (as originally written) | 400 |
| `data/test/stageB_test_fixed/` | test-set results, LLM arms (corrected penalty rule) | 400 |
| `data/ledgers/stageB_gp/` | per-event cost ledgers, evaluation-matched GP control | 50 |
| `data/test/stageB_test_gp/` | test-set results, evaluation-matched GP control | 50 |
| `data/ledgers/stageB_gp_cm/` | per-event cost ledgers, candidate-matched GP control | 50 |
| `data/test/stageB_test_gp_cm/` | test-set results, candidate-matched GP control | 50 |
| `data/test/stageB_test_spotcheck/` | test-set results, second-generation spot-check | 50 |

The two GP controls are what the manuscript's central methodological point
rests on. Under an **evaluation-matched** comparison the GP arm buys many
more candidates for the same number of oracle calls, because the LLM arm
spends part of its budget on failed calls and retries. Under a
**candidate-matched** comparison the verdict changes on two of the five
domains. `code/gp_candidate_matched.py` regenerates the second arm; the
first is the `GP` arm of `code/gp_stageb.py`.

---

## Requirements

Python 3.9 or later, and:

```
numpy
scipy
```

```bash
pip install -r requirements.txt
```

No API key is needed to regenerate any number in the paper. The scripts
that *run* a search (rather than re-read its log) require a model
endpoint; they are included for completeness and are not needed for
reproduction.

---

## Scripts

| File | What it does |
|---|---|
| `code/reproduce.py` | **the main entry point.** Prints the manuscript's tables and verifies the statistics the manuscript quotes. |
| `code/gp_stageb.py` | the evaluation-matched GP control (re-runs a search; needs a model endpoint) |
| `code/gp_candidate_matched.py` | the candidate-matched GP control (re-runs a search; needs a model endpoint) |
| `code/codehh_pilot.py` | the shared harness: ledgers, evaluation, the search loop |
| `code/eval_test_fixed.py` | re-reads the logged runs and computes the test-set results under the idempotent penalty rule |
| `code/spotcheck.py` | the second-generation spot-check, standalone |
| `code/holm_check.py` | the Holm correction for the five-domain family, standalone |

---

## Reproducing the manuscript's tables

The single entry point is `code/reproduce.py`. It needs no `make`:

```bash
# all tables at once
python code/reproduce.py --table all

# one table
python code/reproduce.py --table 19

# check the statistics the manuscript quotes in its abstract and Section 12
python code/reproduce.py --verify
```

On Linux or macOS the `Makefile` wraps the same calls:

```bash
make all        # every table
make verify     # the quoted statistics
make table19    # one table
```

If `make` is not installed (Windows, for instance), use the `python`
commands above; they are what the Makefile runs.

| Table in the paper | What it shows | Command |
|---|---|---|
| 6  | the penalty bug: realised vs intended penalty | `--table 6` |
| 7  | penalty-strength sensitivity, analytic vs measured slope | `--table 7` |
| 8  | failure modes: degeneration and stagnation rates | `--table 8` |
| 17 | three-denominator read: the single-caliber demonstration | `--table 17` |
| 18 | realised budgets and which constraint binds | `--table 18` |
| 19 | effect sizes and rank tests | `--table 19` |
| 21 | candidate-matched vs evaluation-matched control | `--table 21` |
| 24 | second-generation spot-check | `--table 24` |

Tables 4 and 5 state definitions rather than computed quantities, and
Table 22 is the checklist audit, whose scores were obtained by reading
the eight audited manuscripts; both are reproduced in the manuscript
source under `manuscript/` rather than by a script.

Each table is printed to standard output in LaTeX tabular form, so the
output can be redirected into the manuscript:

```bash
python code/reproduce.py --table 19 > tables/table19.tex
```

`--verify` recomputes the summary statistics quoted in the abstract and
in Section 12 and checks them against the values printed in the
manuscript; it exits non-zero if any of them disagrees. It checks, from
the released data alone:

- that the candidate-matched arm reverses the verdict on exactly two of
  the five domains, and which two;
- that the degeneration counts are 1 (flow-shop) and 6 (CVRP);
- that the spot-check degeneration rate is 9 of 50;
- that, after Holm correction within the five-domain family, only TSP
  remains significant at $\alpha=0.05$.

### A note on the p-values

`code/reproduce.py` reports the Mann--Whitney $U$ $p$-values by the
normal approximation, with neither a continuity correction nor a tie
correction, which is what the manuscript's tables contain. The exact
permutation test that a current SciPy would choose by default gives
smaller values on the same data ($0.019$, $0.002$, $0.151$, $1.000$,
$0.021$ against the reported $0.038$, $0.008$, $0.141$, $1.000$,
$0.019$). The reported values are therefore the conservative ones, and
the manuscript states the approximation it used.

---

## Data format

A **ledger** is a JSON object with one record per event of a search run.
Each event carries the fields the protocol requires:

| Field | Meaning |
|---|---|
| `event` | `start`, `init`, `eval`, `select`, `crossover`, `end` |
| `candidate_hash` | SHA-256 of the candidate program |
| `prompt_hash` | SHA-256 of the rendered prompt |
| `prompt_tokens`, `completion_tokens` | token counts |
| `evaluation_count` | number of validation instances charged |
| `wallclock_delta` | seconds since the previous event |
| `instance_ids` | which instances were evaluated |
| `degenerate` | whether every candidate crashed the evaluator |

A **test result** file records the outcome of one run on the held-out
test set:

```json
{
  "domain": "cvrp",
  "config": "E1_6",
  "seed": 3,
  "val_best": 0.0123,
  "test_matched": 0.0094,
  "test_shifted": null,
  "degenerate": false,
  "n_crash": 0
}
```

`test_matched` is the matched-read value of Definition 3.4 at the
realized cap; `test_shifted` is the same read on the shifted tier, and is
`null` where the domain has no second tier. A degenerate run carries the
finite penalty in `test_matched` rather than a quality value, which is
why every table that averages outcomes states how it treats them.

---

## Reproducing the runs themselves

The 400 LLM search runs, the two GP controls and the spot-check were
executed at a pinned model snapshot with the harnesses in `code/`:

```bash
python code/gp_stageb.py --domain cvrp --seeds 10           # GP, evaluation-matched
python code/gp_candidate_matched.py --domain cvrp --seeds 10  # GP, candidate-matched
python code/eval_test_fixed.py --domains bpp,tsp,flow,cvrp,rmfs  # re-read the logs
```

These need a model endpoint and therefore an API key: the harness reads
it from the environment variable `LLM_API_KEY`, or from a `.llm_key` file
next to the script, and the model and base URL from `.llm_model` and
`.llm_base`. **They are not required** to check any number in the paper:
the ledgers they produced are in `data/`, and every script that reads
them works offline.

---

## Licensing

Code: MIT (see `LICENSE`).

Data: the ledgers and test results in `data/` are research data produced
by the author and are released under the same MIT licence. The benchmark
instances are generated by the instance generators in `code/`, except for
the standard test sets named in the manuscript (TSPLIB instances for
TSP, NEH constructions for flow-shop), which remain under their original
terms.

---

## Citation

See `CITATION.cff`. If you use this artifact, please also cite the
manuscript and the checklist, which is the reusable output of the work:
the fourteen-item reporting checklist in Section 12 of the paper is
intended to be applied by others.

---

## Provenance

Every number in the manuscript was computed from the files in `data/` by
the scripts in `code/`. Where an earlier version of the analysis pipeline
contained a defect, the defect is part of the record rather than removed:
`code/protocol_numbers.py` computes both the corrected and the defective
penalty, because the comparison between them is the manuscript's Section
5 negative case.

## A note on peer review and this artifact

*Journal of Heuristics* reviews single-anonymized: author identities are
known to reviewers, reviewer identities are not disclosed to authors. The
manuscript is therefore submitted with the author details in the title
page, and **no anonymized version of this artifact is required**. The
repository can be public from the outset, which is why it is published
here rather than behind a request.
