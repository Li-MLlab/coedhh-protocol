# -*- coding: utf-8 -*-
"""Spot-check comparison restricted to non-degenerate runs.

Degenerate runs carry the finite penalty, not a quality value, so they
cannot be averaged with real outcomes. The comparison therefore uses the
median test quality over non-degenerate runs only, and reports the
degeneration counts separately.
"""
import io, json, glob, os, sys, statistics as st

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

DOMS = ['bpp', 'tsp', 'flow', 'cvrp', 'rmfs']
PRIMARY = os.path.join(ROOT, 'data', 'test', 'stageB_test_fixed')
SPOT = os.path.join(ROOT, 'data', 'test', 'stageB_test_spotcheck')


def load(root, dom):
    out = {}
    for f in glob.glob('%s/%s/*/test_*.json' % (root, dom)):
        d = json.load(open(f, encoding='utf-8'))
        if 'error' not in d:
            out[(d['config'], d['seed'])] = d
    return out


def med_nondeg(d):
    v = [x['test_matched'] for x in d.values() if not x.get('degenerate')]
    return (st.median(v) if v else float('nan'), len(v),
            sum(1 for x in d.values() if x.get('degenerate')), len(d))


print('%-6s %-6s | %-28s | %-28s' % ('domain', 'cfg', 'primary (med, n, deg)',
                                      'spot-check (med, n, deg)'))
rows = []
for dom in DOMS:
    P = load(PRIMARY, dom)
    S = load(SPOT, dom)
    shared = sorted(set(k[0] for k in S) & set(k[0] for k in P))
    for cfg in shared:
        pm, pn, pd_, pt = med_nondeg({k: v for k, v in P.items() if k[0] == cfg})
        sm, sn, sd, stot = med_nondeg({k: v for k, v in S.items() if k[0] == cfg})
        print('%-6s %-6s | %8.4f  n=%d d=%d/%d | %8.4f  n=%d d=%d/%d'
              % (dom, cfg, pm, pn, pd_, pt, sm, sn, sd, stot))
        rows.append((dom, cfg, pm, sm, pd_, pt, sd, stot))
    print()

print('=== summary ===')
tot_p = sum(r[5] for r in rows)
tot_s = sum(r[6] for r in rows)
tot_n = sum(r[7] for r in rows)
print('degeneration: primary %d/%d runs (%.1f%%), spot-check %d/%d runs (%.1f%%)'
      % (tot_p, tot_n, 100 * tot_p / tot_n, tot_s, tot_n, 100 * tot_s / tot_n))
print()
print('best shared config per domain, non-degenerate median:')
for dom in DOMS:
    rr = [r for r in rows if r[0] == dom]
    if not rr:
        continue
    bp = min(rr, key=lambda r: r[2])
    bs = min(rr, key=lambda r: r[3])
    print('%-6s primary %s (%.4f) | spot %s (%.4f) | same: %s'
          % (dom, bp[1], bp[2], bs[1], bs[3], 'yes' if bp[1] == bs[1] else 'NO'))
