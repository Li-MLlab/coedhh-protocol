# -*- coding: utf-8 -*-
"""
CoDe-HH Stage-A pilot pipeline (protocol v1.1/v1.2, paper §5).
Multi-domain implementation validation: bin packing (bpp), TSP (tsp),
permutation flow-shop (flow). Arms per domain: Hand (BF/NN/LPT), GP, LLM,
LLMR (with reflection, EC.2 A.3). Ledgers per EC.5; matched-read estimator
per Definition 3.3.

Usage:
  python codehh_pilot.py --stage smoke     # minutes-scale smoke test
  python codehh_pilot.py --stage A         # implementation validation (never evidence)
Stage B/C scale-up points are marked with [SCALE].
"""
import argparse, hashlib, json, math, os, random, re, time, zlib
from datetime import datetime, timezone

def stable_seed(*parts):
    """Reproducible seed from strings/ints (Python hash() is process-randomized)."""
    return zlib.crc32(repr(parts).encode()) & 0xffffffff

# ------------------------------------------------------------- helpers ----
def guard_eval(src):
    """eval generated lambda with a minimal namespace; returns fn or raises."""
    return eval(src, {"min": min, "max": max, "abs": abs, "len": len,
                      "sum": sum, "sorted": sorted})

def argmax_score(items, score_fn):
    best, best_s = None, -math.inf
    for it in items:
        s = score_fn(it)
        if s > best_s:
            best, best_s = it, s
    return best

# =================================================================
# Domain: online bin packing (bpp)
# =================================================================
BPP_CAP = 100.0

def bpp_make(rng, n_items):
    return [min(BPP_CAP, rng.weibullvariate(15.0, 1.6)) for _ in range(n_items)]

def bpp_l1(items):
    return math.ceil(sum(items) / BPP_CAP)

def bpp_l2(items, capacity=BPP_CAP):
    """Martello-Toth L2 lower bound (Martello & Toth 1990):
    for alpha in [0, c/2]: J1={w<alpha}, J2={alpha<=w<=c-alpha}, J3={w>c-alpha};
    L(alpha) = |J2|+|J3| + max(0, ceil((sum(J1) - slack(J2))/c)),
    slack(J2) = |J2|*c - sum(J2);  L2 = max_alpha L(alpha)  (>= L1).
    Correctness is asserted against brute-force optima in tests."""
    c = capacity
    w = [x for x in items if 0 < x <= c]
    best = math.ceil(sum(w) / c)                    # L1
    # MT sets: J1 large (>c-a, own bin), J2 medium (c/2<w<=c-a, pairwise
    # incompatible -> own bin, slack fills with J3), J3 small (a<=w<=c/2)
    # fills J2 slack then fresh bins; items < a are dropped (valid LB).
    for a in sorted({0.0} | {x for x in w if x <= c / 2.0}):
        J1 = [x for x in w if x > c - a]
        J2 = [x for x in w if c / 2.0 < x <= c - a]
        J3 = [x for x in w if a <= x <= c / 2.0]
        slack = sum(c - x for x in J2)
        over = sum(J3) - slack
        extra = math.ceil(over / c) if over > 0 else 0
        best = max(best, len(J1) + len(J2) + extra)
    return best

def bpp_pack(items, score_fn):
    bins = []  # [residual, load]
    for it in items:
        feas = [(b[0], b[1], k) for k, b in enumerate(bins) if b[0] >= it]
        if feas:
            F = 1.0
            k = max(feas, key=lambda t: score_fn(it, t[0], t[1], F))[2]
            bins[k][0] -= it
            bins[k][1] += it
        else:
            bins.append([BPP_CAP - it, it])
    return len(bins)

def bpp_evaluate(fn, instances):
    if not instances:
        return 1e9
    try:
        excess = sum(max(0, bpp_pack(it, fn) - bpp_l2(it)) for it in instances)
        return excess / len(instances)
    except Exception:
        return 1e9

def bpp_hand_bf(i, r, l, f):
    return r

BPP = {
    "key": "bpp", "label": "Online bin packing",
    "make": bpp_make, "evaluate": bpp_evaluate,
    "term_vars": {"i": "I", "r": "R", "l": "L", "f": "F"},
    "sig": "lambda I,R,L,F:",
    "hand": {"BF": bpp_hand_bf},
    "val_size": 100, "n_val": 50,
    "llm_spec": (
        "You are designing a heuristic for online bin packing.\n"
        "Specification: choose the open bin (residual R, load L) for item I;\n"
        "larger score wins; must depend only on I,R,L,F (F=capacity/100).\n"),
    "llm_sig": "lambda I,R,L,F:",
}

# =================================================================
# Domain: TSP construction via node scoring (tsp)
# =================================================================
def tsp_make(rng, n):
    pts = [(rng.random(), rng.random()) for _ in range(n)]
    D = [[math.dist(pts[i], pts[j]) for j in range(n)] for i in range(n)]
    inst = {"D": D, "n": n}
    inst["ref"] = tsp_tour_len(D, tsp_reference_tour(D, tsp_nn_tour(D)))   # pinned reference [SCALE: Concorde]
    return inst

def tsp_nn_tour(D):
    n = len(D)
    tour, unv = [0], set(range(1, n))
    while unv:
        cur = tour[-1]
        nxt = min(unv, key=lambda j: D[cur][j])
        tour.append(nxt)
        unv.remove(nxt)
    return tour

def tsp_tour_len(D, tour):
    return sum(D[tour[k]][tour[(k + 1) % len(tour)]] for k in range(len(tour)))

def tsp_two_opt_tour(D, tour):
    n, improved = len(tour), True
    while improved:
        improved = False
        for a in range(n - 2):
            for b in range(a + 2, n):
                i1, i2, j1, j2 = tour[a], tour[a + 1], tour[b], tour[(b + 1) % n]
                if D[i1][j1] + D[i2][j2] < D[i1][i2] + D[j1][j2] - 1e-12:
                    tour[a + 1:b + 1] = reversed(tour[a + 1:b + 1])
                    improved = True
    return tour

def tsp_or_opt_tour(D, tour):
    """Segment relocation (length 1-3, both orientations) to local optimality.
    Delta-based on cyclic edges; bounded rounds."""
    n = len(tour)
    cur = list(tour)
    for _ in range(20):
        improved = False
        for L in (1, 2, 3):
            if n - L < 2:
                continue
            for i in range(n):
                seg = [cur[(i + k) % n] for k in range(L)]
                s0, s1 = seg[0], seg[-1]
                prev, nxt = cur[(i - 1) % n], cur[(i + L) % n]
                removed = D[prev][s0] + D[s1][nxt]
                a0 = removed - D[prev][nxt]          # net change from removal
                rest = [cur[(i + L + k) % n] for k in range(n - L)]
                m = len(rest)
                best_delta, best_cand = -1e-12, None
                for pos in range(m):
                    a, b = rest[pos], rest[(pos + 1) % m]
                    for s in (seg, seg[::-1]):
                        delta = (D[a][s[0]] + D[s[-1]][b] - D[a][b]) - a0
                        if delta < best_delta:
                            best_delta, best_cand = delta, \
                                rest[:pos + 1] + s + rest[pos + 1:]
                if best_cand is not None:
                    cur = best_cand
                    improved = True
        if not improved:
            break
    return cur

def tsp_reference_tour(D, tour):
    """Alternate 2-opt and Or-opt until no improvement (bounded rounds)."""
    cur = tsp_two_opt_tour(D, list(tour))
    for _ in range(10):
        L0 = tsp_tour_len(D, cur)
        cur = tsp_or_opt_tour(D, cur)
        cur = tsp_two_opt_tour(D, cur)
        if tsp_tour_len(D, cur) > L0 - 1e-9:
            break
    return cur

def tsp_two_opt_len(D, tour):
    return tsp_tour_len(D, tsp_two_opt_tour(D, tour))

def tsp_greedy(inst, score_fn):
    D, n, cur = inst["D"], inst["n"], 0
    unv = set(range(1, n))
    length = 0.0
    F = n / 100.0
    while unv:
        feats = []
        dmin = min(D[cur][j] for j in unv)
        dmean = sum(D[cur][j] for j in unv) / len(unv)
        for j in unv:
            feats.append((D[cur][j], dmin, dmean, F, j))
        pick = argmax_score(feats, lambda t: score_fn(t[0], t[1], t[2], t[3]))[4]
        length += D[cur][pick]
        cur = pick
        unv.remove(pick)
    return length + D[cur][0]

def tsp_evaluate(fn, instances):
    if not instances:
        return 1e9
    try:
        ratios = [tsp_greedy(inst, fn) / inst["ref"] - 1.0 for inst in instances]
        return sum(ratios) / len(ratios)
    except Exception:
        return 1e9

def tsp_hand_nn(d, m, a, f):
    return -d   # nearest neighbour: smaller distance wins -> larger score

TSP = {
    "key": "tsp", "label": "TSP (greedy construction)",
    "make": tsp_make, "evaluate": tsp_evaluate,
    "term_vars": {"d": "D", "m": "M", "a": "A", "f": "F"},
    "sig": "lambda D,M,A,F:",
    "hand": {"NN": tsp_hand_nn},
    "val_size": 40, "n_val": 20,
    "llm_spec": (
        "You are designing a heuristic for TSP greedy construction.\n"
        "Specification: standing at the current city, choose the next unvisited\n"
        "city with the LARGEST score; score depends only on D=distance\n"
        "current->candidate, M=shortest distance from current to any unvisited\n"
        "city, A=average such distance, F=n/100.\n"),
    "llm_sig": "lambda D,M,A,F:",
}

# =================================================================
# Domain: permutation flow-shop static priority (flow)
# =================================================================
def flow_make(rng, n_jobs, m_mc):
    p = [[rng.randint(1, 99) for _ in range(m_mc)] for _ in range(n_jobs)]
    inst = {"p": p, "n": n_jobs, "m": m_mc}
    inst["ref"] = flow_makespan(p, flow_neh_seq(p))     # NEH anchor (paper metric)
    return inst

def flow_makespan(p, seq):
    m = len(p[0])
    C = [[0] * m for _ in seq]
    for k, j in enumerate(seq):
        for t in range(m):
            prev = C[k - 1][t] if k else 0
            up = C[k][t - 1] if t else 0
            C[k][t] = max(prev, up) + p[j][t]
    return C[-1][-1]

def flow_neh_seq(p):
    order = sorted(range(len(p)), key=lambda j: -sum(p[j]))
    seq = []
    for j in order:
        best, best_len = None, math.inf
        for pos in range(len(seq) + 1):
            cand = seq[:pos] + [j] + seq[pos:]
            L = flow_makespan(p, cand)
            if L < best_len:
                best, best_len = cand, L
        seq = best
    return seq

def flow_evaluate(fn, instances):
    if not instances:
        return 1e9
    try:
        ratios = []
        for inst in instances:
            p, n = inst["p"], inst["n"]
            F = n / 20.0
            feats = []
            for j in range(n):
                row = p[j]
                feats.append((sum(row), sum(row) / len(row), max(row), min(row),
                              row[0], row[-1], F, j))
            pick = sorted(feats, key=lambda t: -fn(t[0], t[1], t[2], t[3], t[4], t[5], t[6]))
            seq = [t[7] for t in pick]
            ratios.append(flow_makespan(p, seq) / inst["ref"] - 1.0)
        return sum(ratios) / len(ratios)
    except Exception:
        return 1e9

def flow_hand_lpt(t, m, x, n, p1, pm, f):
    return t   # largest total work first

FLOW = {
    "key": "flow", "label": "Permutation flow-shop (static priority)",
    "make": flow_make, "evaluate": flow_evaluate,
    "term_vars": {"t": "T", "u": "M", "x": "X", "n": "N", "p": "P1", "q": "PM", "f": "F"},
    "sig": "lambda T,M,X,N,P1,PM,F:",
    "hand": {"LPT": flow_hand_lpt},
    "val_size": (15, 4), "n_val": 20,
    "llm_spec": (
        "You are designing a priority rule for permutation flow-shop scheduling.\n"
        "Specification: jobs are sequenced by priority (larger score = earlier);\n"
        "score depends only on T=total work of the job, M=mean processing time,\n"
        "X=max, N=min, P1=first-machine time, PM=last-machine time, F=jobs/20.\n"),
    "llm_sig": "lambda T,M,X,N,P1,PM,F:",
}


# =================================================================
# Domain: CVRP savings construction (cvrp)
# =================================================================
def cvrp_make(rng, n):
    pts = [(rng.random(), rng.random()) for _ in range(n)]
    dep = (0.5, 0.5)
    q = [rng.randint(5, 20) for _ in range(n)]
    Q = 50
    D = [[math.dist(pts[i], pts[j]) for j in range(n)] for i in range(n)]
    d0 = [math.dist(dep, p) for p in pts]
    inst = {"D": D, "d0": d0, "q": q, "Q": Q, "n": n}
    routes = cvrp_cw(inst, None)                     # classic savings
    inst["ref"] = cvrp_total(inst, routes, two_opt=True)  # [SCALE: best-known]
    return inst

def cvrp_cw(inst, score_fn):
    """Clarke-Wright style merges; score_fn(S,R,Qd,F) picks the merge
    (larger wins). score_fn=None -> classic savings rule."""
    D, d0, q, Q, n = inst["D"], inst["d0"], inst["q"], inst["Q"], inst["n"]
    routes = [[j] for j in range(n)]
    dem = list(q)
    while True:
        best, bs = None, -math.inf
        for a in range(len(routes)):
            for b in range(len(routes)):
                if a == b:
                    continue
                if dem[a] + dem[b] > Q:
                    continue
                i_end = routes[a][-1]
                j_st = routes[b][0]
                S = d0[i_end] + d0[j_st] - D[i_end][j_st]
                R = Q - dem[a] - dem[b]
                Qd = (dem[a] + dem[b]) / Q
                F = n / 50.0
                s = S if score_fn is None else score_fn(S, R, Qd, F)
                if s > bs:
                    bs, best = s, (a, b)
        if best is None:
            break
        a, b = best
        routes[a] = routes[a] + routes[b]
        dem[a] += dem[b]
        routes.pop(b)
        dem.pop(b)
    return routes

def cvrp_route_len(inst, route):
    D, d0 = inst["D"], inst["d0"]
    L = d0[route[0]] + d0[route[-1]]
    L += sum(D[route[k]][route[k + 1]] for k in range(len(route) - 1))
    return L

def cvrp_two_opt_route(inst, route):
    """Bounded 2-opt within a route; depot legs (-1) included in the delta so
    the objective is the true route length (guarantees termination)."""
    D, d0 = inst["D"], inst["d0"]
    r = list(route)
    n = len(r)
    def dd(x, y):                 # x,y in customers or -1 (=depot)
        if x == -1:
            return d0[y]
        if y == -1:
            return d0[x]
        return D[x][y]
    for _ in range(15):           # bounded passes [SCALE]
        improved = False
        for a in range(n):
            for b in range(a + 1, n):
                prev = r[a - 1] if a > 0 else -1
                nxt = r[b + 1] if b + 1 < n else -1
                delta = (dd(prev, r[b]) + dd(r[a], nxt)
                         - dd(prev, r[a]) - dd(r[b], nxt))
                if delta < -1e-9:
                    r[a:b + 1] = reversed(r[a:b + 1])
                    improved = True
        if not improved:
            break
    return r

def cvrp_total(inst, routes, two_opt=False):
    if two_opt:
        routes = [cvrp_two_opt_route(inst, r) for r in routes]
    return sum(cvrp_route_len(inst, r) for r in routes)

def cvrp_evaluate(fn, instances):
    if not instances:
        return 1e9
    try:
        ratios = []
        for inst in instances:
            routes = cvrp_cw(inst, fn)
            ratios.append(cvrp_total(inst, routes) / inst["ref"] - 1.0)
        return sum(ratios) / len(ratios)
    except Exception:
        return 1e9

def cvrp_hand_cw(s, r, qd, f):
    return s

CVRP = {
    "key": "cvrp", "label": "CVRP savings construction",
    "make": cvrp_make, "evaluate": cvrp_evaluate,
    "term_vars": {"s": "S", "r": "R", "q": "Qd", "f": "F"},
    "sig": "lambda S,R,Qd,F:",
    "hand": {"CW": cvrp_hand_cw},
    "val_size": 30, "n_val": 20,
    "llm_spec": (
        "You are designing a merge rule for CVRP Clarke-Wright construction.\n"
        "Specification: repeatedly merge route A (ending at customer i) with\n"
        "route B (starting at customer j); the feasible merge with the LARGEST\n"
        "score is applied; score depends only on S=savings of the merge\n"
        "(d(i,0)+d(0,j)-d(i,j)), R=remaining capacity after the merge,\n"
        "Qd=fraction of vehicle capacity used by the merged route, F=n/50.\n"),
    "llm_sig": "lambda S,R,Qd,F:",
    "informed_notes": (
        "Feature semantics: S large = merging saves much distance; R is the\n"
        "capacity slack left after merging (R<0 infeasible, already filtered);\n"
        "Qd near 1 = route nearly full. Classic rule: Clarke-Wright scores the\n"
        "merge by S alone.\n"
        "I/O example: S=0.4, R=10, Qd=0.8, F=0.6 -> e.g. "
        "lambda S,R,Qd,F: S - 0.2*Qd\n"),
}


# =================================================================
# Domain: RMFS online order-to-pod assignment (rmfs)
# =================================================================
def rmfs_make(rng, n_orders):
    """Pre-generated order stream + warehouse layout; simulation is
    deterministic given the instance and the policy (EC.3 pilot pin:
    I=20 item types, P=30 pods x 8 types, S=3 stations on a 10x10 grid,
    exponential inter-arrival, service = 0.2/item)."""
    I, P, S = 20, 30, 3
    pods = [frozenset(rng.sample(range(I), 8)) for _ in range(P)]
    pod_pos = [(rng.randint(0, 9), rng.randint(0, 9)) for _ in range(P)]
    st_pos = [(0, 0), (9, 0), (4, 9)]
    orders, t = [], 0.0
    for _ in range(n_orders):
        t += rng.expovariate(1.0)
        orders.append((t, rng.sample(range(I), rng.randint(1, 4))))
    inst = {"pods": pods, "pod_pos": pod_pos, "st_pos": st_pos,
            "orders": orders, "P": P, "S": S}
    inst["ref"] = rmfs_simulate(inst, lambda A, L, T, F: A / (1.0 + L))
    return inst

def rmfs_simulate(inst, score_fn):
    pods, pod_pos, st_pos = inst["pods"], inst["pod_pos"], inst["st_pos"]
    P, S = inst["P"], inst["S"]
    busy = [0.0] * S
    ct = []
    n = len(inst["orders"])
    F = P / 30.0
    for t_arr, items in inst["orders"][max(0, n // 5):]:   # warm-up truncated
        oset = set(items)
        best_sc, best_s, best_p = -math.inf, 0, 0
        for p in range(P):
            A = len(oset & pods[p]) / len(oset)
            for s in range(S):
                T = abs(pod_pos[p][0] - st_pos[s][0]) + \
                    abs(pod_pos[p][1] - st_pos[s][1])
                L = max(0.0, busy[s] - t_arr)
                sc = score_fn(A, L, T, F)
                if sc > best_sc:
                    best_sc, best_s, best_p = sc, s, p
        start = max(t_arr, busy[best_s])
        finish = start + _t(best_p, best_s, inst) + 0.2 * len(items)
        busy[best_s] = finish
        ct.append(finish - t_arr)
    return sum(ct) / len(ct) if ct else 1e9

def _t(p, s, inst):
    a, b = inst["pod_pos"][p], inst["st_pos"][s]
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def rmfs_evaluate(fn, instances):
    if not instances:
        return 1e9
    try:
        ratios = [rmfs_simulate(inst, fn) / inst["ref"] - 1.0 for inst in instances]
        return sum(ratios) / len(ratios)
    except Exception:
        return 1e9

def rmfs_hand_myopic(A, L, T, F):
    return A   # myopic greedy: affinity only (paper Table 3)

RMFS = {
    "key": "rmfs", "label": "RMFS order-to-pod assignment (DES)",
    "make": rmfs_make, "evaluate": rmfs_evaluate,
    "term_vars": {"a": "A", "l": "L", "t": "T", "f": "F"},
    "sig": "lambda A,L,T,F:",
    "hand": {"MY": rmfs_hand_myopic},
    "val_size": 150, "n_val": 10,
    "llm_spec": (
        "You are designing an online assignment rule for a robotic mobile\n"
        "fulfillment system.\n"
        "Specification: when an order arrives, choose the (pod, station) pair\n"
        "with the LARGEST score; score depends only on A=order-pod affinity\n"
        "(fraction of the order's item types stored in the pod), L=queue\n"
        "pressure at the station (remaining busy time), T=travel time from pod\n"
        "to station, F=pods/30.\n"),
    "llm_sig": "lambda A,L,T,F:",
    "informed_notes": (
        "Feature semantics: A in [0,1], higher = pod holds more of the order's\n"
        "items; L is the station's remaining busy time (0 = idle); T is the\n"
        "robot travel time. Classic rule: myopic affinity-only (score = A).\n"
        "I/O example: A=0.75, L=2.0, T=6.0, F=1.0 -> e.g. "
        "lambda A,L,T,F: A - 0.1*L\n"),
}

DOMAINS = {"bpp": BPP, "tsp": TSP, "flow": FLOW, "cvrp": CVRP,
          "rmfs": RMFS}

# --------------------------------------------------------------- GP arm ----
TERMINALS_FALLBACK = ["c"]
FUNCS = [("add", 2), ("sub", 2), ("mul", 2), ("min", 2), ("max", 2), ("ifgt", 3)]

def rand_tree(rng, domain, depth):
    terms = list(domain["term_vars"].keys()) + ["c"]
    if depth <= 0 or rng.random() < 0.3:
        t = rng.choice(terms)
        return (t, rng.uniform(0.0, 1.0)) if t == "c" else (t,)
    f = rng.choice(FUNCS)
    return (f[0],) + tuple(rand_tree(rng, domain, depth - 1) for _ in range(f[1]))

def compile_tree(tree, domain):
    """Compile a GP tree into the domain's scoring lambda (guarded namespace)."""
    def rec(node):
        op = node[0]
        if op in domain["term_vars"]:
            return domain["term_vars"][op]
        if op == "c":
            return repr(float(node[1]))
        a = rec(node[1])
        if op == "add": return "(%s+%s)" % (a, rec(node[2]))
        if op == "sub": return "(%s-%s)" % (a, rec(node[2]))
        if op == "mul": return "(%s*%s)" % (a, rec(node[2]))
        if op == "min": return "min(%s,%s)" % (a, rec(node[2]))
        if op == "max": return "max(%s,%s)" % (a, rec(node[2]))
        if op == "ifgt":  # if first arg exceeds 10% of third then first else second
            b = rec(node[2])
            return "((%s) if (%s>0.1*%s) else (%s))" % (a, a, rec(node[3]), b)
        raise ValueError(op)
    src = domain["sig"] + " " + rec(tree)
    return guard_eval(src), src

def tree_mutate(rng, domain, tree, p=0.2):
    if len(tree) == 1 or tree[0] == "c":
        return rand_tree(rng, domain, 2) if rng.random() < p else tree
    if rng.random() < p:
        return rand_tree(rng, domain, 2)
    kids = list(tree[1:])
    k = rng.randrange(len(kids))
    kids[k] = tree_mutate(rng, domain, kids[k], p)
    return (tree[0],) + tuple(kids)

def tree_crossover(rng, domain, a, b):
    if len(a) == 1 or a[0] == "c" or rng.random() < 0.1:
        return b if rng.random() < 0.5 else a
    kids = list(a[1:])
    k = rng.randrange(len(kids))
    pick = b if (len(b) > 1 and b[0] != "c") else a
    kids[k] = tree_crossover(rng, domain, kids[k], pick)
    return (a[0],) + tuple(kids)

def tree_hash(tree):
    return hashlib.sha1(repr(tree).encode()).hexdigest()[:12]

# -------------------------------------------------------------- LLM arm ----
def llm_credentials():
    """env vars first, then .llm_key / .llm_model / .llm_base next to script."""
    here = os.path.dirname(os.path.abspath(__file__))
    base = os.environ.get("LLM_API_BASE")
    key = os.environ.get("LLM_API_KEY")
    model = os.environ.get("LLM_MODEL")
    for name, var in ((".llm_base", "base"), (".llm_key", "key"), (".llm_model", "model")):
        p = os.path.join(here, name)
        if os.path.exists(p):
            val = open(p, encoding="utf-8").read().strip()
            if var == "base" and not base:
                base = val
            if var == "key" and not key:
                key = val
            if var == "model" and not model:
                model = val
    return (base or "https://apihub.agnes-ai.com/v1"), key, (model or "agnes-3.0-flash")

def llm_available():
    return llm_credentials()[1] is not None

LLM_LAST_ERROR = None

def llm_call(messages, cfg):
    """One chat call; returns (text, total_tokens) or (None, tokens).
    Retries throttling (429/5xx) and transient network errors with backoff;
    records the final failure cause in LLM_LAST_ERROR for ledger logging."""
    global LLM_LAST_ERROR
    import urllib.request, urllib.error
    base, key, model = llm_credentials()
    body = json.dumps({"model": model, "temperature": cfg.get("temperature", 1.0),
                       "messages": messages}).encode()
    req = urllib.request.Request(base + "/chat/completions", data=body,
                                 headers={"Authorization": "Bearer " + key,
                                          "Content-Type": "application/json"})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=cfg.get("timeout", 60)) as r:
                out = json.loads(r.read().decode())
            LLM_LAST_ERROR = None
            return out["choices"][0]["message"]["content"], \
                out.get("usage", {}).get("total_tokens", 0)
        except urllib.error.HTTPError as e:
            LLM_LAST_ERROR = "HTTP %d" % e.code
            if e.code == 429 or 500 <= e.code < 600:
                time.sleep((0, 5, 15)[attempt])
                continue
            break
        except Exception as e:
            LLM_LAST_ERROR = type(e).__name__ + ": " + str(e)[:80]
            time.sleep((0, 5, 15)[attempt])
    return None, 0

def llm_propose(domain, pop_text, lessons, cfg):
    """Minimal proposal prompt (EC.2 A.1) + optional reflection lessons (A.3)."""
    messages = [{"role": "user", "content": domain["llm_spec"] +
                 "Here is the current population, ranked by validation fitness:\n"
                 + (pop_text or "(empty)") +
                 (("\n\nLessons from earlier evaluations:\n" + lessons) if lessons else "") +
                 "\nPropose a new candidate that improves upon them.\n"
                 "Return: (1) a one-line description; (2) exactly one line starting\n"
                 "with 'CODE:' followed by a python lambda " + domain["llm_sig"] +
                 " <expression>"}]
    text, tok = llm_call(messages, cfg)
    if text is None:
        return None, tok
    # primary: CODE: marker (tolerate markdown bold/decoration)
    m = re.search(r"CODE\s*[：:]\s*\**\s*(lambda\b[^\n]+)", text)
    if not m:
        # fallback: locate the domain signature anywhere and take that line
        args = domain["llm_sig"].split("lambda", 1)[1].strip().rstrip(":").replace(" ", "")
        m2 = re.search(r"lambda\s+" + re.escape(args) + r"\s*:\s*([^\n]+)", text)
        if m2:
            return ("lambda " + args + ": " + m2.group(1).strip().strip("`"), tok)
        return None, tok
    return (m.group(1).strip().strip("`"), tok)

def llm_reflect(domain, best, worst, cfg):
    """ReEvo-style reflection (EC.2 A.3): verbalize why best beats worst."""
    messages = [{"role": "user", "content":
                 "Best candidate (val %.4f): %s\nWorst candidate (val %.4f): %s\n"
                 "Identify concrete, reusable lessons about why the best\n"
                 "outperforms the worst. Output at most %d lessons, one sentence\n"
                 "each, addressing feature use; edge cases; scaling behavior."
                 % (best[1], best[0][:200], worst[1], worst[0][:200],
                    cfg.get("k_lessons", 3))}]
    text, tok = llm_call(messages, cfg)
    return (text or ""), tok

# ------------------------------------------------------- ledger / curves ----
class Ledger:
    """Per-event cost ledger; schema per EC.5.3."""
    def __init__(self, path):
        self.path, self.t0 = path, time.time()
        self.rows = []
    def log(self, **kw):
        kw["ts"] = round(time.time() - self.t0, 3)
        self.rows.append(kw)
    def save(self, meta):
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump({"meta": meta, "events": self.rows}, f, indent=1)

def bestsofar_curve(events, denom, quality):
    pts, best, cum = [], math.inf, 0.0
    for e in events:
        if e["type"] != "eval":
            continue
        cum += e.get(denom, 0.0) or 0.0
        best = min(best, e[quality])
        pts.append((cum, best))
    return pts

def matched_read(curve, cap):
    """M_R = best-so-far value at the regime cap (paper Definition 3.3):
    the best (smallest, worse-is-larger) quality among evaluation events
    whose cumulative regime-denominator consumption is <= cap."""
    vals = [q for b, q in curve if b <= cap]
    return min(vals) if vals else math.inf

# ------------------------------------------------------------ search loop ----
def make_val_instances(domain, rng, n_val):
    sz = domain["val_size"]
    mk = (lambda: domain["make"](rng, *sz)) if isinstance(sz, tuple) \
        else (lambda: domain["make"](rng, sz))
    return [mk() for _ in range(n_val)]

def run_arm(domain_key, arm, val_insts, seed, out_dir, caps, llm=False):
    dom = DOMAINS[domain_key]
    rng = random.Random(stable_seed(domain_key, arm, seed))
    os.makedirs(out_dir, exist_ok=True)
    led = Ledger(os.path.join(out_dir, "ledger_%s_s%d.json" % (arm, seed)))
    led.log(type="start", domain=domain_key, arm=arm, seed=seed)
    ev_each = len(val_insts)

    if arm in dom["hand"]:
        fn = dom["hand"][arm]
        j = dom["evaluate"](fn, val_insts)
        led.log(type="eval", evals=ev_each, tok=0, wall=0.0, val=j, cand="hand-" + arm)
        best_j, best_src = j, "hand"

    elif arm == "GP":
        scored = []
        for _ in range(caps["pop"]):
            tr = rand_tree(rng, dom, 3)
            fn, _ = compile_tree(tr, dom)
            j = dom["evaluate"](fn, val_insts)
            led.log(type="eval", evals=ev_each, tok=0, wall=0.0, val=j,
                    cand=tree_hash(tr))
            scored.append((j, tr, fn))
        scored.sort(key=lambda x: x[0])
        for _ in range(caps["gens"]):
            parents = sorted(rng.sample(scored, min(4, len(scored))),
                             key=lambda x: x[0])[:2]
            child = tree_crossover(rng, dom, parents[0][1], parents[1][1])
            child = tree_mutate(rng, dom, child)
            fn, _ = compile_tree(child, dom)
            j = dom["evaluate"](fn, val_insts)
            led.log(type="eval", evals=ev_each, tok=0, wall=0.0, val=j,
                    cand=tree_hash(child))
            scored.append((j, child, fn))
            scored.sort(key=lambda x: x[0])
            scored = scored[:caps["pop"]]
        best_j, _, best_fn = scored[0]
        best_src = "GP"

    elif arm in ("LLM", "LLMR"):                       # [SCALE] Stage B/C loops
        if not llm:
            led.log(type="skip", reason="no credentials")
            led.save({"arm": arm, "seed": seed, "status": "skipped"})
            return None
        seen, lessons, best_fn, best_j, best_src = [], "", None, math.inf, None
        for _ in range(caps["llm_iters"]):
            pop_text = "\n".join("%d. %s (val %.4f)" % (i + 1, d, j)
                                 for i, (d, j) in enumerate(seen[:5]))
            src, tok = llm_propose(dom, pop_text, lessons if arm == "LLMR" else "", caps)
            led.log(type="proposal", tok=tok, wall=0.0, reflected=(arm == "LLMR"))
            if src is None:
                led.log(type="repair", tok=0, wall=0.0, failed=True,
                        reason=LLM_LAST_ERROR)
                continue
            try:
                fn = guard_eval(src)
                j = dom["evaluate"](fn, val_insts)
                led.log(type="eval", evals=ev_each, tok=0, wall=0.0, val=j,
                        cand=hashlib.sha1(src.encode()).hexdigest()[:12])
                seen.append((src, j))
                seen.sort(key=lambda x: x[1])
                if j < best_j:
                    best_j, best_fn, best_src = j, fn, src
            except Exception as e:
                led.log(type="repair", tok=0, wall=0.0, failed=True,
                        reason="exec: " + type(e).__name__)
            if arm == "LLMR" and len(seen) >= 2:
                lessons, rtok = llm_reflect(dom, seen[0], seen[-1], caps)
                led.log(type="reflection", tok=rtok, wall=0.0)
        if best_fn is None:
            led.save({"arm": arm, "seed": seed, "status": "no-parse"})
            return None

    led.log(type="end")
    meta = {"domain": domain_key, "arm": arm, "seed": seed,
            "B_eval": sum(e.get("evals", 0) for e in led.rows),
            "B_tok": sum(e.get("tok", 0) for e in led.rows),
            "B_wall": round(time.time() - led.t0, 3),
            "val_best": best_j, "src": (best_src or "")[:200]}
    for d in ("evals", "tok", "wall"):
        meta["curve_" + d] = bestsofar_curve(
            [e for e in led.rows if e["type"] == "eval"], d, "val")
    meta["M_R1"] = matched_read(meta["curve_evals"], caps.get("cap_evals", math.inf))
    led.save(meta)
    print("  %-5s arm=%-5s seed=%d  B_eval=%-6d B_tok=%-7d val=%.3f"
          % (domain_key, arm, seed, meta["B_eval"], meta["B_tok"], best_j))
    return meta


# ------------------------------------------------- E1 factorial arms ----
# Resolution-IV 2^(4-1) design, generator D = A*B*C (paper §5.3).
# A=F1 prompt informativeness, B=F2 reflection, C=F3 archive,
# D=F4 parent selection. Signs: + = informed/on/MAP-Elites/tournament.
E1_CONFIGS = [
    ("E1_1", "-,-,-,+"), ("E1_2", "+,-,-,-"), ("E1_3", "-,+,-,-"),
    ("E1_4", "+,+,-,+"), ("E1_5", "-,-,+,+"), ("E1_6", "+,-,+,-"),
    ("E1_7", "-,+,+,-"), ("E1_8", "+,+,+,+"),
]

def e1_flags(name):
    for n, s in E1_CONFIGS:
        if n == name:
            f1, f2, f3, f4 = s.split(",")
            return {"F1_informed": f1 == "+", "F2_reflect": f2 == "+",
                    "F3_mapelites": f3 == "+", "F4_tournament": f4 == "+",
                    "config": name}
    raise ValueError(name)

class E1Archive:
    """C3 archive: flat generational (top-pop by val) vs MAP-Elites over a
    generic 2D descriptor (val bucket x code-length bucket) [SCALE: per-domain
    descriptors per EC.3]."""
    def __init__(self, mapelites, pop=8):
        self.me, self.pop = mapelites, pop
        self.cells, self.flat = {}, []
    def add(self, src, val):
        if self.me:
            key = (min(2, int(max(0.0, val) * 100) // 50), min(2, len(src) // 60))
            if key not in self.cells or val < self.cells[key][1]:
                self.cells[key] = (src, val)
        else:
            self.flat.append((src, val))
            self.flat.sort(key=lambda x: x[1])
            self.flat = self.flat[:self.pop]
    def all(self):
        return self.flat if not self.me else list(self.cells.values())
    def parents(self, tournament, rng, k=5):
        pool = self.all()
        if not pool:
            return []
        if tournament and len(pool) > 2:
            picked = []
            for _ in range(k):
                cand = rng.sample(pool, min(3, len(pool)))
                picked.append(min(cand, key=lambda x: x[1]))
            return picked
        return sorted(pool, key=lambda x: x[1])[:k]

def e1_prompt(domain, parents, flags, lessons):
    """F1 minimal vs informed prompt (EC.2 A.1 variants)."""
    pop_text = "\n".join("%d. %s (val %.4f)" % (i + 1, d[:120], v)
                          for i, (d, v) in enumerate(parents)) or "(empty)"
    text = domain["llm_spec"] if flags["F1_informed"] else (
        "You are designing a heuristic. Larger score wins.\n")
    if flags["F1_informed"] and "informed_notes" in domain:
        text += domain["informed_notes"]
    text += ("Current parents (lower val = better):\n" + pop_text)
    if flags["F2_reflect"] and lessons:
        text += "\n\nLessons from earlier evaluations:\n" + lessons
    text += ("\nPropose a new candidate that improves upon them.\n"
             "Return one line starting with CODE: then a python lambda "
             + domain["llm_sig"] + " <expression>")
    return text

def run_e1_arm(domain_key, cfg_name, seed, out_dir, caps):
    """One E1 configuration on one seed, under regime caps (paper §3.3):
    stop when B_eval or B_tok cap is reached; matched-read estimator reads
    the best-so-far curves at the caps."""
    import urllib.error                      # noqa: F401 (llm_call uses it)
    dom = DOMAINS[domain_key]
    flags = e1_flags(cfg_name)
    rng = random.Random(stable_seed("E1", domain_key, cfg_name, seed))
    os.makedirs(out_dir, exist_ok=True)
    led = Ledger(os.path.join(out_dir, "ledger_%s_s%d.json" % (cfg_name, seed)))
    led.log(type="start", domain=domain_key, arm=cfg_name, seed=seed, **flags)
    ev_each = len(_val_insts)
    arch = E1Archive(flags["F3_mapelites"], pop=caps.get("pop", 8))
    lessons, seen, best, best_src = "", [], math.inf, None
    it = 0
    while it < caps.get("max_iters", 30):
        b_eval = sum(e.get("evals", 0) for e in led.rows)
        b_tok = sum(e.get("tok", 0) for e in led.rows)
        if b_eval >= caps.get("cap_evals", math.inf) or \
           b_tok >= caps.get("cap_tok", math.inf):
            led.log(type="cap_stop", B_eval=b_eval, B_tok=b_tok)
            break
        parents = arch.parents(flags["F4_tournament"], rng)
        if flags["F2_reflect"] and len(seen) >= 2:
            lessons, rtok = llm_reflect(dom, seen[0], seen[-1], caps)
            led.log(type="reflection", tok=rtok, wall=0.0)
        src, tok = llm_propose_e1(dom, parents, flags, lessons, caps)
        led.log(type="proposal", tok=tok, wall=0.0,
                reflected=flags["F2_reflect"], informed=flags["F1_informed"])
        it += 1
        if src is None:
            led.log(type="repair", tok=0, wall=0.0, failed=True,
                    reason=LLM_LAST_ERROR)
            continue
        try:
            fn = guard_eval(src)
            j = dom["evaluate"](fn, _val_insts)
            led.log(type="eval", evals=ev_each, tok=0, wall=0.0, val=j,
                    cand=hashlib.sha1(src.encode()).hexdigest()[:12])
            arch.add(src, j)
            seen.append((src, j))
            seen.sort(key=lambda x: x[1])
            if j < best:
                best, best_src = j, src
        except Exception as e:
            led.log(type="repair", tok=0, wall=0.0, failed=True,
                    reason="exec: " + type(e).__name__)
    led.log(type="end")
    meta = {"domain": domain_key, "arm": cfg_name, "seed": seed, **flags,
            "B_eval": sum(e.get("evals", 0) for e in led.rows),
            "B_tok": sum(e.get("tok", 0) for e in led.rows),
            "B_wall": round(time.time() - led.t0, 3),
            "val_best": best, "src": (best_src or "")}   # full source (test eval needs it)
    for d in ("evals", "tok", "wall"):
        meta["curve_" + d] = bestsofar_curve(
            [e for e in led.rows if e["type"] == "eval"], d, "val")
    meta["M_R1"] = matched_read(meta["curve_evals"], caps.get("cap_evals", math.inf))
    meta["M_R3"] = matched_read(meta["curve_tok"], caps.get("cap_tok", math.inf))
    led.save(meta)
    print("  %-5s %-5s seed=%d B_eval=%-5d B_tok=%-6d val=%.4f"
          % (domain_key, cfg_name, seed, meta["B_eval"], meta["B_tok"], best))
    return meta

def llm_propose_e1(dom, parents, flags, lessons, caps):
    messages = [{"role": "user", "content":
                 e1_prompt(dom, parents, flags, lessons)}]
    text, tok = llm_call(messages, caps)
    if text is None:
        return None, tok
    m = re.search(r"CODE\s*[：:]\s*\**\s*(lambda\b[^\n]+)", text)
    if not m:
        args = dom["llm_sig"].split("lambda", 1)[1].strip().rstrip(":").replace(" ", "")
        m2 = re.search(r"lambda\s+" + re.escape(args) + r"\s*:\s*([^\n]+)", text)
        if m2:
            return ("lambda " + args + ": " + m2.group(1).strip().strip("`"), tok)
        return None, tok
    return (m.group(1).strip().strip("`"), tok)

_val_insts = []

# ----------------------------------------------------------------- main ----
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", default="A", choices=["A", "smoke", "B1"])
    ap.add_argument("--domains", default="bpp,tsp,flow,cvrp")
    ap.add_argument("--outdir", default="runs")
    ap.add_argument("--arms", default="")      # B1: comma list of E1_n
    ap.add_argument("--seeds", default="1,2,3,4,5")
    a = ap.parse_args()
    smoke = a.stage == "smoke"
    if a.stage == "B1":
        global _val_insts
        dom = DOMAINS[a.domains.split(",")[0]]
        rngI = random.Random(stable_seed(a.domains, "B1val"))
        _val_insts[:] = make_val_instances(dom, rngI, dom["n_val"])
        capsB = {"pop": 8, "cap_evals": 400, "cap_tok": 30000, "max_iters": 12,
                 "k_lessons": 3, "temperature": 1.0}
        seeds = [int(s) for s in a.seeds.split(",") if s.strip()]
        want = [s.strip() for s in a.arms.split(",") if s.strip()] \
            or [n for n, _ in E1_CONFIGS]
        print("Stage-B1 preview (NOT evidence): domain=%s arms=%s seeds=%s caps=%s"
              % (a.domains, want, seeds, {k: capsB[k] for k in ("cap_evals", "cap_tok")}))
        for cfg_name in want:
            for seed in seeds:
                run_e1_arm(a.domains.split(",")[0], cfg_name, seed,
                           os.path.join(a.outdir, "stageB1", a.domains, cfg_name), capsB)
        print("B1 preview done. Ledgers in %s/stageB1/" % a.outdir)
        return
    caps = {"pop": 10 if smoke else 16, "gens": 2 if smoke else 6,
            "llm_iters": 2 if smoke else 4, "cap_evals": math.inf,
            "k_lessons": 3, "temperature": 1.0}
    n_seeds = 1 if smoke else 3
    llm_on = llm_available()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    arms_base = ["HAND", "GP"] + (["LLM", "LLMR"] if llm_on else ["LLM", "LLMR"])

    print("CoDe-HH Stage-A pilot (%s) llm=%s domains=%s" % (stamp, llm_on, a.domains))
    for dkey in a.domains.split(","):
        dom = DOMAINS[dkey]
        hand_name = list(dom["hand"].keys())[0]
        arms = [hand_name if ha == "HAND" else ha for ha in arms_base]
        for arm in arms:
            for seed in range(1, n_seeds + 1):
                rng = random.Random(stable_seed(dkey, "inst", seed))
                val_insts = make_val_instances(dom, rng, 3 if smoke else dom["n_val"])
                run_arm(dkey, arm, val_insts, seed,
                        os.path.join(a.outdir, "stageA", dkey, arm),
                        caps, llm=llm_on)
    print("Stage-A complete: implementation validation only, NOT evidence "
          "(paper §5, protocol v1.1/v1.2). Ledgers in %s/stageA/" % a.outdir)

if __name__ == "__main__":
    main()
