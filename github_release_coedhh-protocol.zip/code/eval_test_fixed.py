# -*- coding: utf-8 -*-
"""修正版 test 评估：幂等的退化惩罚。

原 eval_test.py 的缺陷：
    finite = [d["test_matched"] for d in <已存在的 test json> if d["test_matched"] < 1e8]
    penalty = 10.0 * max(finite)
由于 finite 包含上一次运行写入的 penalty 值，每跑一次惩罚放大 10 倍
（实测 cvrp 136.42 = 100x 1.3642，flow 21.056 = 100x 0.2106）。

修正：penalty 只从【原始逐实例评估结果】推导，绝不读取已有 test json。
对每个域：
    worst_nondeg = max over runs, over instances of (该实例在所有启发式下的最大值)
    即：对崩溃实例，用"该实例上所有启发式的最差有效值"插补（与原逻辑一致），
    然后 penalty = 10 * max(所有非退化运行的均值)
    其中"非退化"由 val_best < 1e8 判定（来自 ledger，不依赖 test json）。

用法：python eval_test_fixed.py --domains bpp,tsp,flow,cvrp,rmfs
      --root runs/stageB --testroot <新目录>
"""
import argparse, json, glob, os, random, statistics as st
import codehh_pilot as cp

SHIFT = {"bpp": 150, "tsp": 60, "flow": (22, 6), "cvrp": 45, "rmfs": 225}
N_TEST = 100
PENALTY_MULT = 10.0   # 论文声明的倍数


def make_set(domain, kind, n):
    if kind == "matched":
        sz = domain["val_size"]
        rng = random.Random(cp.stable_seed(domain["key"], "testM"))
    else:
        sz = SHIFT[domain["key"]]
        rng = random.Random(cp.stable_seed(domain["key"], "testS"))
    mk = (lambda: domain["make"](rng, *sz)) if isinstance(sz, tuple) \
        else (lambda: domain["make"](rng, sz))
    return [mk() for _ in range(n)]


def per_instance(domain, fn, S):
    out = []
    for I in S:
        try:
            out.append(domain["evaluate"](fn, [I]))
        except Exception:
            out.append(None)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--domains", default="bpp,tsp,flow,cvrp,rmfs")
    ap.add_argument("--root", default="runs/stageB")
    ap.add_argument("--testroot", required=True)
    ap.add_argument("--mult", type=float, default=PENALTY_MULT)
    a = ap.parse_args()

    for dkey in a.domains.split(","):
        dom = cp.DOMAINS[dkey]
        runs = [json.load(open(f, encoding="utf-8"))["meta"]
                for f in sorted(glob.glob(os.path.join(a.root, dkey, "*", "ledger_*.json")))]
        if not runs:
            continue

        test_m = make_set(dom, "matched", N_TEST)
        test_s = make_set(dom, "shifted", N_TEST)

        raw_m, raw_s = [], []
        for meta in runs:
            src = meta.get("src", "")
            fn = None
            if src:
                try:
                    fn = cp.guard_eval(src)
                except Exception:
                    fn = None
            raw_m.append(per_instance(dom, fn, test_m) if fn else [None] * N_TEST)
            raw_s.append(per_instance(dom, fn, test_s) if fn else [None] * N_TEST)

        # 逐实例插补：崩溃实例取该实例上所有启发式的最差有效值
        def impute(raw):
            worst = []
            for j in range(len(raw[0])):
                col = [r[j] for r in raw if r[j] is not None]
                worst.append(max(col) if col else None)
            return worst

        worst_m, worst_s = impute(raw_m), impute(raw_s)

        # ---- 幂等 penalty：只从原始评估推导，不读取已有 test json ----
        # 非退化运行 = val_best < 1e8（来自 ledger，与 test json 无关）
        nondeg_idx = [i for i, m in enumerate(runs) if m["val_best"] < 1e8]
        cand = []
        for i in nondeg_idx:
            vm = [worst_m[j] if v is None else v for j, v in enumerate(raw_m[i])]
            vs = [worst_s[j] if v is None else v for j, v in enumerate(raw_s[i])]
            if any(x is None for x in vm) or any(x is None for x in vs):
                continue
            cand.append(st.mean(vm))
            cand.append(st.mean(vs))
        if not cand:
            print("%-5s SKIP: no non-degenerate runs" % dkey)
            continue
        penalty = a.mult * max(cand)

        for i, (meta, rm, rs) in enumerate(zip(runs, raw_m, raw_s)):
            cfg_name = meta.get("config", meta.get("arm", "unknown"))
            vm = [worst_m[j] if v is None else v for j, v in enumerate(rm)]
            vs = [worst_s[j] if v is None else v for j, v in enumerate(rs)]
            if any(x is None for x in vm):
                vm = [penalty if x is None else x for x in vm]
            if any(x is None for x in vs):
                vs = [penalty if x is None else x for x in vs]
            degen = meta["val_best"] >= 1e8
            tm = penalty if degen else st.mean(vm)
            ts = penalty if degen else st.mean(vs)
            res = {"domain": dkey, "config": cfg_name, "seed": meta["seed"],
                   "val_best": meta["val_best"],
                   "test_matched": tm, "test_shifted": ts,
                   "degenerate": degen,
                   "n_crash": sum(1 for v in rm if v is None)
                              + sum(1 for v in rs if v is None),
                   "penalty_used": penalty}
            out_dir = os.path.join(a.testroot, dkey, cfg_name)
            os.makedirs(out_dir, exist_ok=True)
            json.dump(res, open(os.path.join(out_dir,
                                             "test_%s_s%d.json" % (cfg_name, meta["seed"])),
                                "w", encoding="utf-8"), indent=1)

        ndeg = sum(1 for m in runs if m["val_best"] >= 1e8)
        print("%-5s runs=%d degenerate=%d penalty=%.4f (=%gx max non-degenerate mean)"
              % (dkey, len(runs), ndeg, penalty, a.mult))


if __name__ == "__main__":
    main()
