# -*- coding: utf-8 -*-
"""E2 GP-HH 臂：预算匹配（R1, cap_evals=400）的 GP 超启发式对照运行。
与 LLM 臂唯一的范式差异 = 提议算子（子树交叉/变异 vs LLM 采样），
反馈 = 仅适应度（无反射），平存档 + 锦标赛选择（标准 GP 配置，EC.4 pin）。
纯本地计算，无 API。断点续跑（skip-existing）。
用法：python gp_stageb.py --budget 1500 --domains bpp,tsp,flow,cvrp,rmfs
"""
import argparse, json, math, os, random, time
import codehh_pilot as cp

def run_gp(domain_key, seed, out_dir, caps):
    dom = cp.DOMAINS[domain_key]
    rng = random.Random(cp.stable_seed("GP", domain_key, seed))
    val = cp._val_insts
    ev_each = len(val)
    n_cand = caps["cap_evals"] // ev_each
    os.makedirs(out_dir, exist_ok=True)
    led = cp.Ledger(os.path.join(out_dir, "ledger_GP_s%d.json" % seed))
    led.log(type="start", domain=domain_key, arm="GP", seed=seed)
    scored, best, best_src = [], math.inf, None
    for i in range(n_cand):
        if i == 0 or len(scored) < 2:
            tr = cp.rand_tree(rng, dom, 3)
        else:
            parents = sorted(rng.sample(scored, min(3, len(scored))),
                             key=lambda x: x[0])[:2]
            child = cp.tree_crossover(rng, dom, parents[0][1], parents[1][1])
            tr = cp.tree_mutate(rng, dom, child)
        fn, src = cp.compile_tree(tr, dom)
        j = dom["evaluate"](fn, val)
        led.log(type="eval", evals=ev_each, tok=0, wall=0.0, val=j,
                cand=cp.tree_hash(tr))
        scored.append((j, tr, fn))
        scored.sort(key=lambda x: x[0])
        scored = scored[:caps["pop"]]
        if j < best:
            best, best_src = j, src
    led.log(type="end")
    meta = {"domain": domain_key, "arm": "GP", "seed": seed,
            "B_eval": sum(e.get("evals", 0) for e in led.rows),
            "B_tok": 0,
            "B_wall": round(time.time() - led.t0, 3),
            "val_best": best, "src": best_src or ""}
    for d in ("evals", "tok", "wall"):
        meta["curve_" + d] = cp.bestsofar_curve(
            [e for e in led.rows if e["type"] == "eval"], d, "val")
    meta["M_R1"] = cp.matched_read(meta["curve_evals"], caps["cap_evals"])
    led.save(meta)
    print("  %-5s GP seed=%d B_eval=%d val=%.4f" %
          (domain_key, seed, meta["B_eval"], best), flush=True)
    return meta

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--budget", type=int, default=1500)
    ap.add_argument("--domains", default="bpp,tsp,flow,cvrp,rmfs")
    ap.add_argument("--seeds", default="1-10")
    ap.add_argument("--outdir", default="runs/stageB_gp")
    a = ap.parse_args()
    seeds = a.seeds.split("-")
    seed_range = range(int(seeds[0]), int(seeds[-1]) + 1)
    caps = {"pop": 8, "cap_evals": 400}
    grid = [(d, s) for d in a.domains.split(",") for s in seed_range]

    def done(d, s):
        return os.path.exists(os.path.join(a.outdir, d, "GP",
                                           "ledger_GP_s%d.json" % s))

    pending = [g for g in grid if not done(*g)]
    print("grid=%d pending=%d budget=%ds" % (len(grid), len(pending), a.budget),
          flush=True)
    t0, cur_dom = time.time(), None
    for d, s in pending:
        if time.time() - t0 > a.budget:
            print("budget exhausted before %s s%d" % (d, s), flush=True)
            break
        if d != cur_dom:
            rngI = random.Random(cp.stable_seed(d, "stageB"))
            cp._val_insts[:] = cp.make_val_instances(cp.DOMAINS[d], rngI,
                                                     cp.DOMAINS[d]["n_val"])
            cur_dom = d
        run_gp(d, s, os.path.join(a.outdir, d, "GP"), caps)
    still = len([g for g in grid if not done(*g)])
    print("chunk done: remaining=%d elapsed %.0fs" % (still, time.time() - t0),
          flush=True)

if __name__ == "__main__":
    main()
