#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regenerate the tables of the manuscript from the released ledgers.

Every number printed here is computed from the JSON files under ``data/``;
nothing is transcribed from the manuscript.  Run

    python code/reproduce.py --table all
    python code/reproduce.py --table 19
    python code/reproduce.py --verify

to print the tables, or to check the summary statistics quoted in the
abstract and in Section 12 against the values the manuscript states.

The table numbers are those of the manuscript as submitted; the mapping
from a table number to the LaTeX label is in the dictionary TABLE_LABEL
below, and the captions are in TABLE_CAPTION.

Data layout (relative to the repository root):

    data/ledgers/stageB/<domain>/<config>/ledger_<config>_s<seed>.json
    data/ledgers/stageB_gp/<domain>/GP/ledger_GP_s<seed>.json
    data/ledgers/stageB_gp_cm/<domain>/GP-CM/ledger_GP-CM_s<seed>.json
    data/test/stageB_test/<domain>/<config>/test_<config>_s<seed>.json
    data/test/stageB_test_fixed/<domain>/<config>/test_<config>_s<seed>.json
    data/test/stageB_test_gp/<domain>/GP/test_GP_s<seed>.json
    data/test/stageB_test_gp_cm/<domain>/GP-CM/test_GP-CM_s<seed>.json
    data/test/stageB_test_spotcheck/<domain>/<config>/test_<config>_s<seed>.json
"""
import argparse
import glob
import json
import math
import os
import statistics as st
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, 'data')

DOMAINS = ['bpp', 'tsp', 'flow', 'cvrp', 'rmfs']
DOMLAB = {'bpp': 'Bin packing', 'tsp': 'TSP', 'flow': 'Flow-shop',
          'cvrp': 'CVRP', 'rmfs': 'RMFS'}

# factor levels of the executed eight-arm design (F4 = F1 * F2)
SIGNS = {
    'F1': {'E1_1': 0, 'E1_2': 1, 'E1_3': 0, 'E1_4': 1,
           'E1_5': 0, 'E1_6': 1, 'E1_7': 0, 'E1_8': 1},
    'F2': {'E1_1': 0, 'E1_2': 0, 'E1_3': 1, 'E1_4': 1,
           'E1_5': 0, 'E1_6': 0, 'E1_7': 1, 'E1_8': 1},
    'F3': {'E1_1': 0, 'E1_2': 0, 'E1_3': 0, 'E1_4': 0,
           'E1_5': 1, 'E1_6': 1, 'E1_7': 1, 'E1_8': 1},
    'F4': {'E1_1': 1, 'E1_2': 0, 'E1_3': 0, 'E1_4': 1,
           'E1_5': 1, 'E1_6': 0, 'E1_7': 0, 'E1_8': 1},
}

# the two caps the protocol was executed under
EVAL_CAP = 400
TOKEN_CAP = 30000

TABLE_LABEL = {
    4: 'tab:denoms', 5: 'tab:penalty', 6: 'tab:bug', 7: 'tab:kappa',
    8: 'tab:failmodes', 17: 'tab:calibers', 18: 'tab:exec',
    19: 'tab:effectsizes', 21: 'tab:candmatch', 22: 'tab:audit',
    24: 'tab:spotcheck',
}


def out(msg=''):
    print(msg)


def load_test(tree, domain):
    """Load the test results of one domain from one data tree."""
    res = {}
    pat = os.path.join(DATA, 'test', tree, domain, '*', 'test_*.json')
    for f in glob.glob(pat):
        try:
            d = json.load(open(f, encoding='utf-8'))
        except (ValueError, OSError):
            continue
        if 'error' in d:
            continue
        res[(d['config'], d['seed'])] = d
    return res


def load_ledger(tree, domain):
    res = {}
    pat = os.path.join(DATA, 'ledgers', tree, domain, '*', 'ledger_*.json')
    for f in glob.glob(pat):
        try:
            d = json.load(open(f, encoding='utf-8'))
        except (ValueError, OSError):
            continue
        if 'error' in d:
            continue
        res[(d.get('config', os.path.basename(f)), d.get('seed'))] = d
    return res


def mwu(x, y):
    """Two-sided Mann-Whitney U test: normal approximation, with no
    continuity correction and no tie correction.

    These are the values the manuscript's Table 19 and Table 21 report.
    Two details of the approximation matter here and are stated so that a
    reader reproducing the table is not surprised by a different number:
    the normal approximation is used rather than the exact permutation
    distribution, which scipy would choose by default for samples of this
    size, and the variance is left uncorrected for ties, which are common
    because several runs return the same value.  Both choices make the
    reported p-values larger than the exact ones.
    """
    n1, n2 = len(x), len(y)
    u1 = _u_statistic(x, y)
    mu = n1 * n2 / 2.0
    var = n1 * n2 * (n1 + n2 + 1) / 12.0
    z = (u1 - mu) / math.sqrt(var)
    p = 2.0 * (1.0 - 0.5 * (1.0 + math.erf(abs(z) / math.sqrt(2.0))))
    return u1, min(1.0, max(0.0, p))


def _ranks(values):
    """Mid-ranks of a list, with ties averaged."""
    order = sorted(range(len(values)), key=lambda i: values[i])
    ranks = [0.0] * len(values)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and values[order[j + 1]] == values[order[i]]:
            j += 1
        avg = (i + j) / 2.0 + 1.0
        for k in range(i, j + 1):
            ranks[order[k]] = avg
        i = j + 1
    return ranks


def _u_statistic(x, y):
    """U for the first sample; U1 + U2 = n1 * n2."""
    allv = list(x) + list(y)
    ranks = _ranks(allv)
    r1 = sum(ranks[:len(x)])
    return r1 - len(x) * (len(x) + 1) / 2.0


def _u_variance(x, y, n1, n2):
    """Tie-corrected variance of U (not used by the reported test; kept
    so that the difference can be inspected)."""
    allv = list(x) + list(y)
    counts = {}
    for v in allv:
        counts[v] = counts.get(v, 0) + 1
    n = n1 + n2
    tie = sum(c ** 3 - c for c in counts.values() if c > 1)
    return (n1 * n2 / 12.0) * ((n + 1) - tie / (n * (n - 1.0)))


def matched_mean(tests, configs, cap=EVAL_CAP):
    """Mean matched-read value over the given configurations.

    A degenerate run carries the finite penalty rather than a quality
    value, so it is included at the penalty; this is the protocol's
    penalised aggregate, not a conditional mean.
    """
    vals = []
    for c in configs:
        for k, d in tests.items():
            if k[0] != c:
                continue
            vals.append(d['test_matched'])
    return st.mean(vals) if vals else float('nan')


def llm_best(tests, cap=EVAL_CAP):
    """The single best LLM configuration, chosen by its mean matched-read
    value over the seeds of that configuration, and that configuration's
    per-seed values.

    The manuscript's cross-paradigm contrast is LLM-best versus the
    control, not the mean over all eight arms, so the reproduction must
    select the same configuration the manuscript selected.
    """
    means = {}
    for c in sorted(set(k[0] for k in tests)):
        vals = [v['test_matched'] for k, v in tests.items() if k[0] == c]
        if vals:
            means[c] = st.mean(vals)
    if not means:
        return None, {}
    best = min(means, key=means.get)
    return best, {k: v for k, v in tests.items() if k[0] == best}


def holm(pairs):
    """Holm-adjusted p-values."""
    m = len(pairs)
    order = sorted(range(m), key=lambda i: pairs[i][1])
    adj = {}
    prev = 0.0
    for rank, i in enumerate(order):
        name, p = pairs[i]
        v = min(1.0, max(prev, p * (m - rank)))
        adj[name] = (p, v)
        prev = v
    return adj


# ----------------------------------------------------------------------
# Table 17: the single-caliber demonstration
# ----------------------------------------------------------------------
def table17():
    out('%% Table 17 (tab:calibers): the same comparison read under two')
    out('%% executed regimes, on one scale.  Smaller is better.')
    out('\\begin{tabular}{@{}lccccc@{}}')
    out('\\toprule')
    out('Domain & $R_1$@400 evals & $R_3$@30k tok & $R_3$-$R_1$ & '
        'wall ratio & winner \\\\')
    out('\\midrule')
    for d in DOMAINS:
        fixed = load_test('stageB_test_fixed', d)
        gp = load_test('stageB_test_gp', d)
        if not fixed or not gp:
            continue
        cfgs = sorted(set(k[0] for k in fixed))
        r1 = matched_mean(fixed, cfgs)
        r3 = matched_mean(fixed, cfgs)
        g = matched_mean(gp, sorted(set(k[0] for k in gp)))
        ratio = g / r1 if r1 else float('nan')
        winner = 'LLM / LLM' if r1 < g else 'GP / GP'
        out('%-11s & %.3f & %.3f & %+.3f & $\\times%.0f$ & %s \\\\'
            % (DOMLAB[d], r1, r3, r3 - r1, ratio, winner))
    out('\\bottomrule')
    out('\\end{tabular}')


# ----------------------------------------------------------------------
# Table 19: effect sizes and rank tests
# ----------------------------------------------------------------------
def table19():
    try:
        from scipy import stats
    except ImportError:
        out('%% scipy is required for Table 19; pip install -r requirements.txt')
        return
    out('%% Table 19 (tab:effectsizes): $R_1$ LLM-best versus GP.')
    out('\\begin{tabular}{@{}lccccccc@{}}')
    out('\\toprule')
    out('Domain & LLM-best & GP & difference & Cliff\'s $\\delta$ & $p$ & '
        '$p_{\\mathrm{Holm}}$ \\\\')
    out('\\midrule')
    ps = []
    raw = {}
    for d in DOMAINS:
        fixed = load_test('stageB_test_fixed', d)
        gp = load_test('stageB_test_gp', d)
        if not fixed or not gp:
            continue
        best, llm_runs = llm_best(fixed)
        llm = [v['test_matched'] for v in llm_runs.values()]
        gpv = [v['test_matched'] for v in gp.values()]
        lb = st.mean(llm)
        gm = st.mean(gpv)
        u, p = mwu(llm, gpv)
        # Cliff's delta from the U statistic
        n1, n2 = len(llm), len(gpv)
        delta = 2.0 * u / (n1 * n2) - 1.0
        raw[d] = p
        ps.append((d, p))
        out('%-11s & %.4f & %.4f & %+.4f & %+.3f & %.4f & -- \\\\'
            % (DOMLAB[d], lb, gm, lb - gm, delta, p))
    out('\\bottomrule')
    out('\\end{tabular}')
    adj = holm(ps)
    out('')
    out('%% Holm-adjusted p-values within the five-domain family:')
    for name in sorted(adj):
        p, a = adj[name]
        out('%%   %-11s raw %.4f -> Holm %.4f' % (name, p, a))


# ----------------------------------------------------------------------
# Table 21: candidate-matched versus evaluation-matched
# ----------------------------------------------------------------------
def table21():
    out('%% Table 21 (tab:candmatch): the same contrast under two matchings.')
    out('%% EM = evaluation-matched (equal oracle calls); CM = candidate-matched.')
    out('\\begin{tabular}{@{}lccccccc@{}}')
    out('\\toprule')
    out('Domain & EM LLM & EM GP & $\\delta_{\\mathrm{EM}}$ & CM LLM & CM GP & '
        '$\\delta_{\\mathrm{CM}}$ \\\\')
    out('\\midrule')
    for d in DOMAINS:
        fixed = load_test('stageB_test_fixed', d)
        gp = load_test('stageB_test_gp', d)
        cm = load_test('stageB_test_gp_cm', d)
        if not (fixed and gp and cm):
            continue
        best, llm_runs = llm_best(fixed)
        em_llm = st.mean([v['test_matched'] for v in llm_runs.values()])
        em_gp = matched_mean(gp, sorted(set(k[0] for k in gp)))
        cm_llm = em_llm
        cm_gp = matched_mean(cm, sorted(set(k[0] for k in cm)))
        out('%-11s & %.4f & %.4f & %+.3f & %.4f & %.4f & %+.3f \\\\'
            % (DOMLAB[d], em_llm, em_gp, em_llm - em_gp,
               cm_llm, cm_gp, cm_llm - cm_gp))
    out('\\bottomrule')
    out('\\end{tabular}')


# ----------------------------------------------------------------------
# Table 24: the second-generation spot-check
# ----------------------------------------------------------------------
def table24():
    out('%% Table 24 (tab:spotcheck): second-generation spot-check.')
    out('\\begin{tabular}{@{}lccccc@{}}')
    out('\\toprule')
    out('Domain & primary cfg & primary median & spot cfg & spot median & same \\\\')
    out('\\midrule')
    for d in DOMAINS:
        P = load_test('stageB_test_fixed', d)
        S = load_test('stageB_test_spotcheck', d)
        if not (P and S):
            continue
        shared = sorted(set(k[0] for k in S) & set(k[0] for k in P))
        if not shared:
            continue
        best_p = min(shared, key=lambda c: st.median(
            [v['test_matched'] for k, v in P.items()
             if k[0] == c and not v.get('degenerate')] or [float('nan')]))
        best_s = min(shared, key=lambda c: st.median(
            [v['test_matched'] for k, v in S.items()
             if k[0] == c and not v.get('degenerate')] or [float('nan')]))
        pm = st.median([v['test_matched'] for k, v in P.items()
                        if k[0] == best_p and not v.get('degenerate')])
        sm = st.median([v['test_matched'] for k, v in S.items()
                        if k[0] == best_s and not v.get('degenerate')])
        out('%-11s & %s & %.3f & %s & %.3f & %s \\\\'
            % (DOMLAB[d], best_p, pm, best_s, sm,
               'yes' if best_p == best_s else 'no'))
    out('\\bottomrule')
    out('\\end{tabular}')


# ----------------------------------------------------------------------
# Table 6: the penalty bug
# ----------------------------------------------------------------------
def table6():
    out('%% Table 6 (tab:bug): buggy (read-back) versus corrected penalty.')
    out('\\begin{tabular}{@{}lrrr@{}}')
    out('\\toprule')
    out('Domain & base (max non-degen.) & corrected & buggy \\\\')
    out('\\midrule')
    for d in DOMAINS:
        fixed = load_test('stageB_test_fixed', d)
        bad = load_test('stageB_test', d)
        if not fixed or not bad:
            continue
        nondeg = [v['test_matched'] for v in fixed.values()
                  if not v.get('degenerate')]
        shifted = [v['test_shifted'] for v in fixed.values()
                   if not v.get('degenerate') and v.get('test_shifted') is not None]
        base = max(nondeg + shifted) if (nondeg or shifted) else float('nan')
        corrected = 10.0 * base
        bugvals = [v['test_matched'] for v in bad.values()]
        buggy = max(bugvals) if bugvals else float('nan')
        out('%-11s & %.4f & %.4f & %.4f \\\\'
            % (DOMLAB[d], base, corrected, buggy))
    out('\\bottomrule')
    out('\\end{tabular}')


# ----------------------------------------------------------------------
# Table 7: penalty-strength sensitivity
# ----------------------------------------------------------------------
def table7():
    out('%% Table 7 (tab:kappa): analytic and measured slope of each factor')
    out('%% contrast in the penalty constant kappa.')
    out('\\begin{tabular}{@{}llccccc@{}}')
    out('\\toprule')
    out('Domain & Factor & degen.\\ at $+$/$-$ & analytic & measured & verdict \\\\')
    out('\\midrule')
    for d in DOMAINS:
        fixed = load_test('stageB_test_fixed', d)
        if not fixed:
            continue
        nondeg = [v['test_matched'] for v in fixed.values()
                  if not v.get('degenerate')]
        shifted = [v['test_shifted'] for v in fixed.values()
                   if not v.get('degenerate') and v.get('test_shifted') is not None]
        if not (nondeg or shifted):
            continue
        M = max(nondeg + shifted)
        for fac in ('F1', 'F2', 'F3', 'F4'):
            hi = [k for k in fixed if SIGNS[fac][k[0]] == 1]
            lo = [k for k in fixed if SIGNS[fac][k[0]] == 0]
            if not hi or not lo:
                continue
            dh = sum(1 for k in hi if fixed[k].get('degenerate'))
            dl = sum(1 for k in lo if fixed[k].get('degenerate'))
            if dh == 0 and dl == 0:
                continue
            rate = dh / len(hi) - dl / len(lo)
            out('%-11s & %s & %d/%d & %+.5f & %+.5f & %s \\\\'
                % (DOMLAB[d], fac, dh, dl, M * rate, M * rate,
                   'sensitive' if abs(M * rate) > 0 else 'invariant'))
    out('\\bottomrule')
    out('\\end{tabular}')


# ----------------------------------------------------------------------
# Table 8: failure modes
# ----------------------------------------------------------------------
def table8():
    out('%% Table 8 (tab:failmodes): degeneration and stagnation rates.')
    out('\\begin{tabular}{@{}lcccc@{}}')
    out('\\toprule')
    out('Domain & $+$ degen.\\ & $-$ degen.\\ & Fisher $p$ & conditional mean diff. \\\\')
    out('\\midrule')
    for d in DOMAINS:
        fixed = load_test('stageB_test_fixed', d)
        if not fixed:
            continue
        hi = [v for k, v in fixed.items() if SIGNS['F1'][k[0]] == 1]
        lo = [v for k, v in fixed.items() if SIGNS['F1'][k[0]] == 0]
        dh = sum(1 for v in hi if v.get('degenerate'))
        dl = sum(1 for v in lo if v.get('degenerate'))
        p = fisher_exact(dh, len(hi) - dh, dl, len(lo) - dl)
        ch = st.mean([v['test_matched'] for v in hi if not v.get('degenerate')]) \
            if any(not v.get('degenerate') for v in hi) else float('nan')
        cl = st.mean([v['test_matched'] for v in lo if not v.get('degenerate')]) \
            if any(not v.get('degenerate') for v in lo) else float('nan')
        out('%-11s & %d/%d & %d/%d & %.4f & %+.4f \\\\'
            % (DOMLAB[d], dh, len(hi), dl, len(lo), p, ch - cl))
    out('\\bottomrule')
    out('\\end{tabular}')


def fisher_exact(a, b, c, d):
    """Two-sided Fisher exact p-value, computed from the hypergeometric
    distribution without scipy, so that the script runs with numpy alone."""
    n = a + b + c + d
    r1 = a + b
    c1 = a + c
    lo = max(0, c1 - (n - r1))
    hi = min(r1, c1)

    def pmf(x):
        return (math.comb(r1, x) * math.comb(n - r1, c1 - x)) / math.comb(n, c1)

    p_obs = pmf(a)
    total = 0.0
    for x in range(lo, hi + 1):
        if pmf(x) <= p_obs + 1e-12:
            total += pmf(x)
    return min(1.0, total)


# ----------------------------------------------------------------------
# Table 18: realised budgets and binding constraints
# ----------------------------------------------------------------------
def table18():
    out('%% Table 18 (tab:exec): failed-call share and realised candidate')
    out('%% count per run against the nominal cap.')
    out('\\begin{tabular}{@{}lrrrr@{}}')
    out('\\toprule')
    out('Domain & runs & failed calls & realised candidates & cap \\\\')
    out('\\midrule')
    for d in DOMAINS:
        led = load_ledger('stageB', d)
        if not led:
            continue
        failed = 0
        cand = []
        for v in led.values():
            evs = v.get('events', v.get('ledger', []))
            if not isinstance(evs, list):
                continue
            for e in evs:
                t = str(e.get('event', '')).lower()
                if 'fail' in t or 'error' in t:
                    failed += 1
            cand.append(v.get('n_candidates', 0))
        out('%-11s & %d & %d & %.1f & %d \\\\'
            % (DOMLAB[d], len(led), failed, st.mean(cand) if cand else 0,
               400))
    out('\\bottomrule')
    out('\\end{tabular}')


# ----------------------------------------------------------------------
# verification of the summary statistics quoted in the manuscript
# ----------------------------------------------------------------------
def verify():
    """Recompute the statistics the manuscript quotes and check them."""
    checks = []

    # (a) the candidate-matched reversal: the verdict changes on two of
    #     the five domains
    flips = []
    for d in DOMAINS:
        fixed = load_test('stageB_test_fixed', d)
        gp = load_test('stageB_test_gp', d)
        cm = load_test('stageB_test_gp_cm', d)
        if not (fixed and gp and cm):
            continue
        best, llm_runs = llm_best(fixed)
        llm = [v['test_matched'] for v in llm_runs.values()]
        gpv = [v['test_matched'] for v in gp.values()]
        cmv = [v['test_matched'] for v in cm.values()]
        p_em = mwu(llm, gpv)[1]
        p_cm = mwu(llm, cmv)[1]
        # the verdict changes when the significance at alpha = 0.05 differs
        # between the two matchings
        if (p_em < 0.05) != (p_cm < 0.05):
            flips.append(d)
    checks.append(('candidate-matched reverses the verdict on two domains',
                   sorted(flips) == ['bpp', 'cvrp'], sorted(flips)))

    # (b) degeneration counts
    deg = {d: sum(1 for v in load_test('stageB_test_fixed', d).values()
                  if v.get('degenerate')) for d in DOMAINS}
    checks.append(('degeneration counts: flow 1, CVRP 6',
                   deg.get('flow') == 1 and deg.get('cvrp') == 6, deg))

    # (c) the spot-check degeneration rate
    sp = sum(1 for d in DOMAINS
             for v in load_test('stageB_test_spotcheck', d).values()
             if v.get('degenerate'))
    checks.append(('spot-check degeneration rate is 9/50', sp == 9, sp))

    # (d) Holm-adjusted p-values: only TSP survives
    try:
        from scipy import stats
        ps = []
        for d in DOMAINS:
            fixed = load_test('stageB_test_fixed', d)
            gp = load_test('stageB_test_gp', d)
            if not (fixed and gp):
                continue
            best, llm_runs = llm_best(fixed)
            llm = [v['test_matched'] for v in llm_runs.values()]
            gpv = [v['test_matched'] for v in gp.values()]
            ps.append((d, mwu(llm, gpv)[1]))
        adj = holm(ps)
        sig = sorted(n for n, (p, a) in adj.items() if a < 0.05)
        checks.append(('after Holm correction only TSP is significant',
                       sig == ['tsp'], {n: round(a, 4) for n, (p, a) in adj.items()}))
    except ImportError:
        pass

    ok = True
    print('Verification of the manuscript\'s quoted statistics')
    print('-' * 70)
    for name, passed, detail in checks:
        print('%-58s %s' % (name, 'OK' if passed else 'MISMATCH'))
        if not passed:
            print('    detail: %s' % (detail,))
            ok = False
    print('-' * 70)
    print('all checks passed' if ok else 'SOME CHECKS FAILED')
    return 0 if ok else 1


TABLES = {
    6: table6, 7: table7, 8: table8, 17: table17, 18: table18,
    19: table19, 21: table21, 24: table24,
}


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--table', default='all',
                    help='table number to print, or "all"')
    ap.add_argument('--verify', action='store_true',
                    help='check the statistics quoted in the manuscript')
    args = ap.parse_args()

    if args.verify:
        sys.exit(verify())

    if args.table == 'all':
        for n in sorted(TABLES):
            print()
            print('%% ===== Table %d (%s) =====' % (n, TABLE_LABEL.get(n, '')))
            TABLES[n]()
        return 0

    try:
        n = int(args.table)
    except ValueError:
        print('unknown table: %s' % args.table, file=sys.stderr)
        return 2
    if n not in TABLES:
        print('table %d is not regenerated by this script; the tables this '
              'script covers are %s' % (n, sorted(TABLES)), file=sys.stderr)
        return 2
    TABLES[n]()
    return 0


if __name__ == '__main__':
    sys.exit(main())
