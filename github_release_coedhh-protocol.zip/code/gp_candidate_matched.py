# -*- coding: utf-8 -*-
"""GP-CM 臂：candidate-matched 的遗传编程对照。

动机（论文2 审稿意见 §2.1/§2.2）：
  原 GP 臂按 400 评估预算运行，其实际评估的候选程序数是 LLM 臂的
  1.00--3.69 倍（因为 GP 本地计算只受评估上限约束，而 LLM 臂还受
  30 次提案尝试上限与 provider 限流拖累）。这使"评估匹配"同时成为
  "候选数不匹配"。本脚本按**候选数**而非评估数匹配：每个域的候选上限
  取该域 LLM 臂实际评估候选数的中位数。

同时补记台账事件（原 GP 台账只有 start/eval/end，缺 selection 与
crossover/mutation，违反论文自设的 per-event ledger 规范）：
  - type=select   : 记录本代选中的两个父代（cand hash）
  - type=crossover: 记录交叉/变异产生的子代（cand hash, parent hashes）
  - type=eval     : 记录评估（沿用原字段）

用法：python gp_candidate_matched.py --seeds 1-10
输出：runs/stageB_gp_cm/<domain>/GP-CM/ledger_GP-CM_s<seed>.json
      runs/stageB_test_gp_cm/<domain>/GP-CM/test_GP-CM_s<seed>.json
"""
import argparse, glob, json, math, os, random, sys, time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import codehh_pilot as cp

# 候选数上限：取各域 LLM 臂实际评估候选数的中位数（见论文的候选匹配一节）
CM_CAPS = {"bpp": 8, "tsp": 19, "flow": 19, "cvrp": 3, "rmfs": 12}

OUT_LEDGER = os.path.join(ROOT, "runs", "stageB_gp_cm")
OUT_TEST = os.path.join(ROOT, "runs", "stageB_test_gp_cm")

# 测试集生成：与 eval_test_fixed.py 完全同口径（SHIFT / N_TEST / stable_seed）
SHIFT = {"bpp": 150, "tsp": 60, "flow": (22, 6), "cvrp": 45, "rmfs": 225}
N_TEST = 100


def make_test_set(domain, kind, n):
    """与 eval_test_fixed.make_set 逐字相同的测试集生成（保证口径一致）。"""
    if kind == "matched":
        sz = domain["val_size"]
        rng = random.Random(cp.stable_seed(domain["key"], "testM"))
    else:
        sz = SHIFT[domain["key"]]
        rng = random.Random(cp.stable_seed(domain["key"], "testS"))
    mk = (lambda: domain["make"](rng, *sz)) if isinstance(sz, tuple) \
        else (lambda: domain["make"](rng, sz))
    return [mk() for _ in range(n)]


def run_gp_cm(domain_key, seed, ledger_root, test_root, cap_cands, pop,
              test_m=None, test_s=None):
    dom = cp.DOMAINS[domain_key]
    rng = random.Random(cp.stable_seed("GP-CM", domain_key, seed))
    val = cp._val_insts
    ev_each = len(val)

    os.makedirs(os.path.join(ledger_root, domain_key, "GP-CM"), exist_ok=True)
    led = cp.Ledger(os.path.join(ledger_root, domain_key, "GP-CM",
                                 "ledger_GP-CM_s%d.json" % seed))
    led.log(type="start", domain=domain_key, arm="GP-CM", seed=seed,
            cap_cands=cap_cands, pop=pop)

    scored, best, best_src = [], math.inf, None
    generations = 0
    for i in range(cap_cands):
        if i == 0 or len(scored) < 2:
            tr = cp.rand_tree(rng, dom, 3)
            led.log(type="init", cand=cp.tree_hash(tr))
        else:
            # 锦标赛选择：随机取 min(3, |scored|) 个，按适应度排序取前 2
            pool = rng.sample(scored, min(3, len(scored)))
            parents = sorted(pool, key=lambda x: x[0])[:2]
            led.log(type="select",
                    cand_p1=cp.tree_hash(parents[0][1]),
                    cand_p2=cp.tree_hash(parents[1][1]),
                    gen=generations)
            child = cp.tree_crossover(rng, dom, parents[0][1], parents[1][1])
            tr = cp.tree_mutate(rng, dom, child)
            led.log(type="crossover",
                    cand=cp.tree_hash(tr),
                    parent_p1=cp.tree_hash(parents[0][1]),
                    parent_p2=cp.tree_hash(parents[1][1]),
                    gen=generations)
        fn, src = cp.compile_tree(tr, dom)
        j = dom["evaluate"](fn, val)
        led.log(type="eval", evals=ev_each, tok=0, wall=0.0, val=j,
                cand=cp.tree_hash(tr))
        scored.append((j, tr, fn))
        scored.sort(key=lambda x: x[0])
        scored = scored[:pop]
        if j < best:
            best, best_src = j, src

    led.log(type="end", generations=generations)

    meta = {"domain": domain_key, "arm": "GP-CM", "seed": seed,
            "B_eval": sum(e.get("evals", 0) for e in led.rows),
            "B_tok": 0,
            "B_wall": round(time.time() - led.t0, 3),
            "val_best": best, "src": best_src or "",
            "cap_cands": cap_cands, "generations": generations,
            "n_candidates_evaluated": cap_cands}
    for d in ("evals", "tok", "wall"):
        meta["curve_" + d] = cp.bestsofar_curve(
            [e for e in led.rows if e["type"] == "eval"], d, "val")
    meta["M_R1"] = cp.matched_read(meta["curve_evals"], cap_cands * ev_each)
    led.save(meta)

    # ---- 测试集评估（与原 GP 臂同口径：test_matched + test_shifted）----
    test_dir = os.path.join(test_root, domain_key, "GP-CM")
    os.makedirs(test_dir, exist_ok=True)
    res = {"domain": domain_key, "config": "GP-CM", "arm": "GP-CM",
           "seed": seed, "val_best": best,
           "test_matched": None, "test_shifted": None,
           "degenerate": False, "n_crash": 0, "src": best_src or "",
           "cap_cands": cap_cands}
    try:
        best_tree = min(scored, key=lambda x: x[0])[1]
        fn_best, _ = cp.compile_tree(best_tree, dom)
        tm = dom["evaluate"](fn_best, test_m) if test_m else None
        ts = dom["evaluate"](fn_best, test_s) if test_s else None
        res["test_matched"] = tm
        res["test_shifted"] = ts
    except Exception as e:                                   # pragma: no cover
        res["error"] = repr(e)
        res["degenerate"] = True
    with open(os.path.join(test_dir, "test_GP-CM_s%d.json" % seed), "w",
              encoding="utf-8") as f:
        json.dump(res, f, indent=1)

    print("  %-5s GP-CM seed=%d cands=%d evals=%d val=%.4f gen=%d"
          % (domain_key, seed, cap_cands, meta["B_eval"], best, generations),
          flush=True)
    return meta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--domains", default="bpp,tsp,flow,cvrp,rmfs")
    ap.add_argument("--seeds", default="1-10")
    ap.add_argument("--pop", type=int, default=8)
    ap.add_argument("--ledger-root", default=OUT_LEDGER)
    ap.add_argument("--test-root", default=OUT_TEST)
    a = ap.parse_args()
    if "-" in a.seeds:
        s0, s1 = a.seeds.split("-")
        seeds = list(range(int(s0), int(s1) + 1))
    else:
        seeds = [int(a.seeds)]
    domains = a.domains.split(",")

    for d in domains:
        dom = cp.DOMAINS[d]
        # 验证集：与 stageB 臂完全同口径（同 seed 公式）
        rngI = random.Random(cp.stable_seed(d, "stageB"))
        cp._val_insts[:] = cp.make_val_instances(dom, rngI, dom["n_val"])
        # 测试集：与 eval_test_fixed.make_set 同口径
        test_m = make_test_set(dom, "matched", N_TEST)
        test_s = make_test_set(dom, "shifted", N_TEST)
        for s in seeds:
            out = os.path.join(a.ledger_root, d, "GP-CM",
                               "ledger_GP-CM_s%d.json" % s)
            if os.path.exists(out):
                print("  skip existing", d, s, flush=True)
                continue
            run_gp_cm(d, s, a.ledger_root, a.test_root,
                      CM_CAPS[d], a.pop, test_m, test_s)


if __name__ == "__main__":
    main()
