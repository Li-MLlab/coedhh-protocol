# -*- coding: utf-8 -*-
"""Holm-adjusted p-values for the five-domain cross-arm family."""
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

RAW = {  # Mann-Whitney U, two-sided, n=10 per domain
    'Bin packing': 0.0376,
    'TSP': 0.0082,
    'Flow-shop': 0.1405,
    'CVRP': 1.0000,
    'RMFS': 0.0191,
}


def holm(pairs):
    """Return {name: (raw, adjusted)}."""
    m = len(pairs)
    order = sorted(range(m), key=lambda i: pairs[i][1])
    adj = {}
    prev = 0.0
    for rank, i in enumerate(order):
        name, p = pairs[i]
        v = min(1.0, max(prev, p * (m - rank)))
        adj[name] = (p, v)
        prev = v
    return adj


items = sorted(RAW.items())
adj = holm(items)
print('%-12s %8s %10s %s' % ('domain', 'raw p', 'Holm p', 'verdict at 0.05'))
for name, _ in items:
    raw, a = adj[name]
    print('%-12s %8.4f %10.4f %s' % (name, raw, a, 'sig' if a < 0.05 else 'not sig'))
print()
sig_raw = [n for n, _ in items if adj[n][0] < 0.05]
sig_adj = [n for n, _ in items if adj[n][1] < 0.05]
print('significant before correction:', sig_raw)
print('significant after  correction:', sig_adj)
